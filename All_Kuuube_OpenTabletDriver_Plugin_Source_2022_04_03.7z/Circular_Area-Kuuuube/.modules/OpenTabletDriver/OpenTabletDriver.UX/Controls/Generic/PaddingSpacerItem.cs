using Eto.Forms;

namespace OpenTabletDriver.UX.Controls.Generic
{
    public class PaddingSpacerItem : StackLayoutItem
    {
        public PaddingSpacerItem()
        {
            this.Control = null;
            this.Expand = true;
        }
    }
}