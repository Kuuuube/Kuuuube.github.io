namespace OpenTabletDriver.SystemDrivers
{
    internal interface IDriverInfoProvider
    {
        DriverInfo GetDriverInfo();
    }
}