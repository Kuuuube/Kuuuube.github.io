using System;

namespace OpenTabletDriver.Plugin.Attributes
{
    [AttributeUsage(AttributeTargets.Class)]
    public class DeviceHubAttribute : Attribute
    {
    }
}