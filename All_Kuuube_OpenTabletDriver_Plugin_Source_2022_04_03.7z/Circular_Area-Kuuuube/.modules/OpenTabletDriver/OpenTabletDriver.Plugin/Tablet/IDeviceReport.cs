namespace OpenTabletDriver.Plugin.Tablet
{
    public interface IDeviceReport
    {
        byte[] Raw { set; get; }
    }
}
