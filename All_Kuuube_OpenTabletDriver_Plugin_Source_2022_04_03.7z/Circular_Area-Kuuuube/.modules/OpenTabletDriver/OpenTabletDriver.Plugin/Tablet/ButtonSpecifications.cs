namespace OpenTabletDriver.Plugin.Tablet
{
    public class ButtonSpecifications
    {
        /// <summary>
        /// The amount of buttons.
        /// </summary>
        public uint ButtonCount { set; get; }
    }
}