namespace OpenTabletDriver.Plugin.Tablet
{
    public enum ToolType
    {
        Pen,
        Eraser
    }
}
