namespace OpenTabletDriver.Native.Linux.Timers
{
    public enum SigEv
    {
        Signal,
        None,
        Thread,
        ThreadID
    }
}