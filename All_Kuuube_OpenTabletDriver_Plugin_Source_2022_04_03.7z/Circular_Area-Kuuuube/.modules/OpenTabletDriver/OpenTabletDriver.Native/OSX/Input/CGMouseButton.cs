﻿namespace OpenTabletDriver.Native.OSX.Input
{
    public enum CGMouseButton : uint
    {
        kCGMouseButtonLeft = 0,
        kCGMouseButtonRight = 1,
        kCGMouseButtonCenter = 2,
        kCGMouseButtonBackward = 3,
        kCGMouseButtonForward = 4,
    }
}