namespace OpenTabletDriver.Native.OSX.Generic
{
    public enum CGEventTapLocation
    {
        kCGHIDEventTap = 0,
        kCGSessionEventTap = 1,
        kCGAnnotatedSessionEventTap = 2
    }
}