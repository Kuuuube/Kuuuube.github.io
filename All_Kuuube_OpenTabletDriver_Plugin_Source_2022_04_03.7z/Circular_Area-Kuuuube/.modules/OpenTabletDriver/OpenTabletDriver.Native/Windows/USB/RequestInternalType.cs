namespace OpenTabletDriver.Native.Windows.USB
{
    public enum RequestInternalType : byte
    {
        Standard,
        Class,
        Vendor
    }
}