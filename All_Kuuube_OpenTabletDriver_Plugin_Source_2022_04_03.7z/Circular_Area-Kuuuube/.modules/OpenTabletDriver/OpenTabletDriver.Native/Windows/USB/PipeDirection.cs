namespace OpenTabletDriver.Native.Windows.USB
{
    public enum PipeDirection
    {
        Out,
        In
    }
}