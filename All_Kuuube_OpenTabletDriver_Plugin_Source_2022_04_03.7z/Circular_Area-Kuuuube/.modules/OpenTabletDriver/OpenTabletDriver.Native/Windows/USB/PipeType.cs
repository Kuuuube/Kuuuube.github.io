namespace OpenTabletDriver.Native.Windows.USB
{
    public enum PipeType : int
    {
        Control,
        Isochronous,
        Bulk,
        Interrupt
    }
}