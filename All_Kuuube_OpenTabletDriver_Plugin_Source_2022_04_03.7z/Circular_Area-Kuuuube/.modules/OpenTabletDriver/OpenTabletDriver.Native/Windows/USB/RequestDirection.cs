namespace OpenTabletDriver.Native.Windows.USB
{
    public enum RequestDirection : byte
    {
        HostToDevice,
        DeviceToHost
    }
}