[<- Back](https://github.com/Kuuuube/Circular_Area/blob/main/wiki/mappings_index.md#mappings-index)

# Approximate Equal Area 2 Vertical

## Diagrams
![](https://raw.githubusercontent.com/Kuuuube/Circular_Area/main/wiki/images/mappings/square_approximate_equal_area_2_vertical_circle_grid_thick_checkerboard.png)
![](https://raw.githubusercontent.com/Kuuuube/Circular_Area/main/wiki/images/mappings/square_approximate_equal_area_2_vertical_square_grid_thick_checkerboard.png)
![](https://raw.githubusercontent.com/Kuuuube/Circular_Area/main/wiki/images/mappings/square_approximate_equal_area_2_vertical_dot_grid_circle_rgb_gradient_circle.png)

## Formula
![](https://raw.githubusercontent.com/Kuuuube/Circular_Area/main/wiki/images/formulas/approximate_equal_area_2_vertical_formula.png)

![](https://raw.githubusercontent.com/Kuuuube/Circular_Area/main/wiki/images/formulas/approximate_equal_area_2_t_variable.png)



# Approximate Equal Area 2 Vertical Inverse 

Note: This mapping is unusable to such a degree that it has been excluded from the plugin.