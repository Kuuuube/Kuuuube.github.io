[<- Back](https://github.com/Kuuuube/Circular_Area/blob/main/wiki/mappings_index.md#mappings-index)

Note: Sham Quartic Mapping mapping is bugged. However, Sham Quartic Mapping Inverse works as intended. Diagrams for this page will be completed when Sham Quartic Mapping is fixed.

# Sham Quartic Mapping

## Formula
![](https://raw.githubusercontent.com/Kuuuube/Circular_Area/main/wiki/images/formulas/sham_quartic_mapping_formula.png)




# Sham Quartic Mapping Inverse

## Formula
![](https://raw.githubusercontent.com/Kuuuube/Circular_Area/main/wiki/images/formulas/sham_quartic_mapping_inverse_formula.png)

Note: Inverse mapping outputs are upscaled by ≈1.4142 to fill the entire monitor area. The inverse mapping formula shown here excludes this.